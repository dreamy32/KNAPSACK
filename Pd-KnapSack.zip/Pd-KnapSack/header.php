<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="//db.onlinewebfonts.com/c/6ab539c6fc2b21ff0b149b3d06d7f97c?family=Minecraft" rel="stylesheet"
        type="text/css" />
    <link rel="stylesheet" href="css/index.css" />
    <link rel="stylesheet" href="css/grid.css" />
    <link rel="stylesheet" href="css/all.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="css/mc-tooltips.css">
    <title><?= $title ?></title>
</head>
<body>
    <div id="minetip-tooltip">
        <span class="minetip-title" id="minetip-text">Minecraft Tip</span>
    </div>
    <div class="container">
        <header class="header">
            <div class="profileInfo fullWidth">
                <span class="fa-stack fa-lg">
                    <i class="fa fa-circle fa-stack-2x cart"></i>
                    <a href="profile.php" style="text-decoration: none;"><i class="fa-solid fa-user fa-stack-1x"></i></a>
                </span>
                <?php 
                    /*
                    include('DB_Procedure.php');
                    $profile = chercherInfoJoueur()
                    $profile[0] : Alias du joueur
                    $profile[1] : Solder du joueur 
                    $profile[2] : poids du joueur
                    $profile[3] : poidsmax du joueur
                    */
                ?>
                <div style="text-align: center;">
                    <span>
                        <?= $profile[0] ?>
                    </span>
                    <br>
                    <span>
                        Solde:
                    </span>
                    <span>
                        <?= $profile[1] ?><img style="width: 20px;" src="images/cap.bmp" alt="caps"></a>
                    </span>
                </div>
                <div class="actions" style="margin-left: 2%; text-align: center;">
                    <i class="fa-solid fa-backpack"></i>
                    <br>
                    <i class="fa-solid fa-money-check-dollar-pen"></i>
                </div>
                <span style="font-size: small;"><i><?=$profile[2]?>/<?=$profile[3]?> lb</i></span>
            </div>
            <?php 
                if($title == "KnapSack"){
                    echo '<div class="advancedSearch"> <p>Recherche Avancée</p> </div>';
                }
            ?>
            <div class="searchAndCart">
                <span class="fa-stack fa-lg">
                    <i class="fa fa-circle fa-stack-2x cart"></i>
                    <a href="panier.php" style="text-decoration: none;"><i class="fa-light fa-cart-shopping fa-stack-1x"></i></a>
                </span>
            </div>
        </header>