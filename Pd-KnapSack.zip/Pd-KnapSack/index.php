<?php 
    $title = "KnapSack";
    require('header.php');
?>
        <main class="item item2">
            <p>Informations</p>
        </main>
        <nav id="style-1" class="item3 minecraft-scrollbar">
            <section>
                <?php 
                    /* En attente de l'implementation des stored procedure 
                        include('DB_Procedure.php');
                        $listeObjets = chercherToutObjetVente();
                        foreach($listeObjets as $objet){
                            echo "<article> <img class="minetext" data-mctitle="$objet[0]&nbsp;$objet[1]" src="images_Objet/$objet[0]$objet[2]"alt="Image de $objet[0]"></article>";
                        }
                        $objet[0] : nom de l'objet
                        $objet[1] : Poids de l'objet
                        $objet[2] : ID de l'objet
                    */
                ?>
                <article>
                    <img class="minetext" data-mctitle="Apple&nbsp;5lb"
                        src="https://www.pikpng.com/pngl/b/560-5600564_minecraft-green-apple-texture-clipart.png"
                        alt="Image de apple">
                </article>
            </section>
        </nav>
    </div>
<?php require('footer.php')?>