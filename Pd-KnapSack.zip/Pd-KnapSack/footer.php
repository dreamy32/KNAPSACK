</div>
<script src="js/mc-tooltips.js"></script>
    <footer>
        <div style="background-color: black; color:white;">
            <p>Devs:  Amélie Bouchard | Antony Collin-Desrochers | David Bérubé | Samy Tétrault</p>
            <p>Dernière mise à jours : 22 Mars 2022</p>
        </div>
    </footer>
</body>
</html>